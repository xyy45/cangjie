# CangSight-Nexus verified project

Run `cjpm build -V` and `cjpm test` from `project/` with the pinned Cangjie 1.0.5 toolchain.
`evidence/` contains original records and their indexes. No SDK, credentials, Git metadata,
or generated target directory is included. Project and archive identities are separate.
The manifest uses SHA256 of file bytes and excludes its own hash. The final ZIP hash is
stored in the external export receipt. This snapshot predates the export completion record.
Passing frozen tests supports only the registered order-case requirements; it does not prove
arbitrary program correctness. See evidence/requirements.json for untested behavior.
